<?php

namespace App\Containers\Login\Actions;

use App\Ship\Parents\Actions\Action;
use App\Ship\Parents\Requests\Request;
use Apiato\Core\Foundation\Facades\Apiato;

class LoginAction extends Action
{
    public function run(Request $request)
    {
      //        $data = $request->sanitizeInput([
      //            // add your request data here
      //        ]);
      $data = $request->all();
      $login = Apiato::call('Login@CreateLoginTask', [$data]);
      //return $login ;
      $user = Apiato::call('User@FindUserByPhoneNumberTask', ['110100103']);

      if (!$user) {
        throw new NotFoundException();
      }

      return $user;


    }
}
