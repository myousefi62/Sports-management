<?php

namespace App\Containers\Login\Models;

use App\Ship\Parents\Models\Model;

class Login extends Model
{
    protected $fillable = [
      "phone_number",
      "api_token"
    ];

    protected $attributes = [

    ];

    protected $hidden = [
      "updated_at",
      "created_at",
    ];

    protected $casts = [

    ];

    protected $dates = [
        'created_at',
        'updated_at',
    ];

    /**
     * A resource key to be used by the the JSON API Serializer responses.
     */
    protected $resourceKey = 'logins';
}
